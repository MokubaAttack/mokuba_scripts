# GENERATED VERSION FILE
# TIME: Sat Aug 22 11:26:15 2026
__version__ = '1.4.2'
__gitsha__ = 'unknown'
version_info = (1, 4, 2)
