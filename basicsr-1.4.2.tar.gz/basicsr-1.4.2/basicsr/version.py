# GENERATED VERSION FILE
# TIME: Mon Nov  9 14:22:24 2026
__version__ = '1.4.2'
__gitsha__ = 'unknown'
version_info = (1, 4, 2)
