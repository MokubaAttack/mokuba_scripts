# GENERATED VERSION FILE
# TIME: Fri Oct 30 15:18:22 2026
__version__ = '1.4.2'
__gitsha__ = 'unknown'
version_info = (1, 4, 2)
